export const projectWGSLHeader = null;
export const projectWGSL = null;
