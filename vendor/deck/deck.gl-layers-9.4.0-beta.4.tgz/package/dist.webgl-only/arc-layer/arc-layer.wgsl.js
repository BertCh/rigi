export const shaderWGSL = null;
