export const getShaderWGSL = () => null;
export const shaderWGSL = null;
