export const getSolidPolygonShaderWGSL = () => null;
