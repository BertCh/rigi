export const getShaderWGSL = () => null;
export default null;
