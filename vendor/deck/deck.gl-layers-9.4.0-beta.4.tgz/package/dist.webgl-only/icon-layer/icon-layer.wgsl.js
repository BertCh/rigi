export const getShaderWGSL = () => null;
