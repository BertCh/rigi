export const getColumnLayerWGSL = () => null;
